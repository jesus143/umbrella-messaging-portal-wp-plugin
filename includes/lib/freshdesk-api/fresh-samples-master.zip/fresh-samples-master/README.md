Sample code for API V2
======================

Samples of code created by freshdesk

